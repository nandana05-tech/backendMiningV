// src/handler.js
const pool = require('./kos');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const crypto = require('crypto');

const ALGORITHM = 'aes-256-cbc';
const SECRET_KEY = crypto.createHash('sha256').update(String('kuncirahasia')).digest();
const IV = Buffer.from('1234567890123456');

function encrypt(text) {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ALGORITHM, SECRET_KEY, iv);
  let encrypted = cipher.update(text, 'utf8', 'base64');
  encrypted += cipher.final('base64');
  return iv.toString('hex') + ':' + encrypted;
}

function decrypt(encryptedText) {
  try {
    const [ivHex, encryptedBase64] = encryptedText.split(':');
    const iv = Buffer.from(ivHex, 'hex');
    const decipher = crypto.createDecipheriv(ALGORITHM, SECRET_KEY, iv);
    let decrypted = decipher.update(encryptedBase64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (err) {
    console.error('Decrypt error:', err.message);
    console.error('Teks yang gagal didecrypt:', encryptedText);
    return null;
  }
}

// 🧍‍♂️ Register Pengguna
exports.registerUser = async (req, h) => {
  const { nama, email, password, role } = req.payload;
  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    await pool.query(
      'INSERT INTO users (nama, email, password, role) VALUES (?, ?, ?, ?)',
      [nama, email, hashedPassword, role]
    );
  
    return h.response({ message: 'Registrasi berhasil' }).code(201); 
  } catch (err) {
    console.error('Error saat registrasi:', err);
    return h.response({ message: 'Gagal registrasi' }).code(500);
  }
};

// 🔑 Login Pengguna
exports.loginUser = async (req, h) => {
  const { email, password } = req.payload;

  try {
    // Cek apakah email ada
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);

    if (rows.length === 0) {
      return h.response({ message: 'Email tidak ditemukan' }).code(404);
    }

    const user = rows[0];
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return h.response({ message: 'Password salah' }).code(401);
    }

    // Buat token baru
    const token = jwt.sign(
      { id: user.id, role: user.role },
      SECRET_KEY
    );

    // Simpan token ke database
    await pool.query('UPDATE users SET token = ? WHERE id = ?', [token, user.id]);

    // Kirim response lengkap
    return h.response({
      message: 'Login berhasil',
      token: token,
      id: user.id,         
      role: user.role,     
      nama: user.nama      
    }).code(200);

  } catch (err) {
    console.error('Error saat login:', err);
    return h.response({ message: 'Terjadi kesalahan server' }).code(500);
  }
};

exports.logoutUser = async (req, h) => {
  const { id } = req.params;

  try {
    // Hapus token dari database
    await pool.query('UPDATE users SET token = NULL WHERE id = ?', [id]);

    return h.response({ message: 'Logout berhasil' }).code(200);
  } catch (err) {
    console.error('❌ Error saat logout:', err);
    return h.response({ message: 'Gagal logout' }).code(500);
  }
};

// 👤 Ambil Detail Profil Berdasarkan ID
exports.getUserById = async (req, h) => {
  const { id } = req.params;

  try {
    const [rows] = await pool.query('SELECT id, nama, email, role FROM users WHERE id = ?', [id]);

    if (rows.length === 0) {
      return h.response({ message: 'Pengguna tidak ditemukan' }).code(404);
    }

    return h.response(rows[0]).code(200);
  } catch (err) {
    console.error('❌ Error saat mengambil profil:', err);
    return h.response({ message: 'Gagal mengambil profil pengguna' }).code(500);
  }
};

// ✏️ Edit Profil Pengguna
exports.updateUser = async (req, h) => {
  const { id } = req.params;
  const { nama, email, password } = req.payload;

  try {
    let query = '';
    let params = [];

    if (password) {
      const hashedPassword = await bcrypt.hash(password, 10);
      query = 'UPDATE users SET nama = ?, email = ?, password = ? WHERE id = ?';
      params = [nama, email, hashedPassword, id];
    } else {
      query = 'UPDATE users SET nama = ?, email = ? WHERE id = ?';
      params = [nama, email, id];
    }

    const [result] = await pool.query(query, params);

    if (result.affectedRows === 0) {
      return h.response({ message: 'Pengguna tidak ditemukan' }).code(404);
    }

    return h.response({ message: 'Profil berhasil diperbarui' }).code(200);
  } catch (err) {
    console.error('❌ Error saat update profil:', err);
    return h.response({ message: 'Gagal memperbarui profil pengguna' }).code(500);
  }
};

// ❌ Hapus Profil Pengguna
exports.deleteUser = async (req, h) => {
  const { id } = req.params;

  try {
    const [result] = await pool.query('DELETE FROM users WHERE id = ?', [id]);

    if (result.affectedRows === 0) {
      return h.response({ message: 'Pengguna tidak ditemukan' }).code(404);
    }

    return h.response({ message: 'Profil berhasil dihapus' }).code(200);
  } catch (err) {
    console.error('❌ Error saat hapus profil:', err);
    return h.response({ message: 'Gagal menghapus profil pengguna' }).code(500);
  }
};