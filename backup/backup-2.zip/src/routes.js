// src/routes.js
const {
  registerUser,
  loginUser,
  logoutUser,
  getUserById,
  updateUser,
  deleteUser,
} = require("./handler");

const routes = [
  // 🧍‍♂️ User Management
  { method: "POST", path: "/register", handler: registerUser },
  { method: "POST", path: "/login", handler: loginUser },
  { method: "DELETE", path: "/logout/{id}", handler: logoutUser },

  // 👤 Profil Pengguna
  { method: "GET", path: "/users/{id}", handler: getUserById },
  { method: "PUT", path: "/users/{id}", handler: updateUser },
  { method: "DELETE", path: "/users/{id}", handler: deleteUser },
];

module.exports = routes;
